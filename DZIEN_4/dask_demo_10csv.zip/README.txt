Dask demo (10 plików CSV)

Zawartość:
  - data/transactions_01.csv ... transactions_10.csv
  - dask_demo.py (przykład użycia Dask DataFrame)
  - README.txt

Instalacja:
  pip install "dask[dataframe]"

Uruchomienie:
  python dask_demo.py

Efekt:
  - wczytanie wszystkich CSV przez wildcard
  - agregacja (count/sum/mean) kwot per kategoria
  - zapis wyniku do out/wynik_*.csv
