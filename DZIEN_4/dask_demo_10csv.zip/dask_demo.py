"""Dask demo: praca na wielu plikach CSV (wildcard) + agregacje.

Wymagania:
  pip install "dask[dataframe]"

Uruchom:
  python dask_demo.py

Co robi skrypt:
  1) Wczytuje 10 plików CSV naraz przez wzorzec data/transactions_*.csv
  2) Pokazuje liczbę partycji (ddf.npartitions) i typy kolumn
  3) Liczy liczbę wierszy (compute) oraz agregację per kategoria (count/sum/mean)
  4) Zapisuje wynik agregacji do out/wynik_*.csv

Uwaga:
  Dask jest 'lazy' (leniwy): operacje budują graf zadań,
  a realne liczenie dzieje się dopiero na .compute().
"""

from pathlib import Path
import dask.dataframe as dd


def main() -> None:
    root = Path(__file__).parent
    data_dir = root / "data"

    # 1) Wczytanie wielu plików naraz (wildcard)
    ddf = dd.read_csv(str(data_dir / "transactions_*.csv"))

    print("=== DASK DATAFRAME ===")
    print("Kolumny:", list(ddf.columns))
    print("Liczba partycji:", ddf.npartitions)
    print("Dtypes:\n", ddf.dtypes)

    # 2) Metryka: liczba rekordów (to jest dopiero compute)
    n_rows = ddf.shape[0].compute()
    print("\nLiczba wierszy:", n_rows)

    # 3) Agregacja: count/sum/mean kwoty per kategoria
    agg_ddf = (
        ddf.groupby("category")["amount"]
           .agg(["count", "sum", "mean"])
           .reset_index()
    )

    agg = agg_ddf.compute().sort_values("sum", ascending=False)
    print("\n=== Agregacja per kategoria ===")
    print(agg)

    # 4) Zapis wyniku
    out_dir = root / "out"
    out_dir.mkdir(exist_ok=True)

    # Dask zapisuje do wielu plików (tu wymuszamy 1 partycję, żeby był jeden wynik)
    dd.from_pandas(agg, npartitions=1).to_csv(str(out_dir / "wynik_*.csv"), index=False)
    print(f"\nZapisano wynik do: {out_dir}")


if __name__ == "__main__":
    main()
